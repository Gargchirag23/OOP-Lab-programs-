JAVA INTERFACES — COMPLETE SLIDE EXAMPLES

Based on both uploaded PowerPoints:
- cgr_unit2_interfaces.pptx
- cgr_unit2_Interfaces_default&static.pptx

Java files:
01_CallbackDemo.java — Callback interface, Client implementation, callback(42), nonIfaceMeth().
02_IFExtend.java — Interface B extends interface A.
03_DefaultMethodDemo.java — Default interface method used without overriding.
04_DefaultMethodOverride.java — MyIFImp2 overrides getString().
05_SayableDemo.java — Default, abstract, and static interface methods.
06_DrawableDemo.java — Drawable implemented by Circle and Rectangle.
07_MultipleInheritanceDemo.java — Class implements Printable and Showable.
08_PartialImplementationDemo.java — Abstract class partially implements Callback.
09_InterfaceConstantDemo.java — Demonstrates implicit interface field/method modifiers.

RUN IN VS CODE
1. Extract this ZIP and open the extracted folder in VS Code.
2. Open Terminal > New Terminal.
3. Check Java: java -version and javac -version
4. Compile and run one program at a time. Example:
   javac 02_IFExtend.java
   java IFExtend

Use the matching public class name for each file. For example:
   javac 05_SayableDemo.java
   java SayableDemo

Requirements: a JDK; Java 8 or later for default and static interface methods.

NOTES
- The Drawable slide has an incomplete getDrawable() line; direct object creation is used here so it runs.
- The partial-implementation slide uses illustrative/unfinished fields; main() sets values to demonstrate output.
- The Printable/Showable example appears twice in the slides and is included once.
- Explanatory slides and diagrams are not separate Java programs.
